#
# TABLE STRUCTURE FOR: tbl_log
#

DROP TABLE IF EXISTS `tbl_log`;

CREATE TABLE `tbl_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) NOT NULL,
  `userName` varchar(128) NOT NULL,
  `process` varchar(1024) NOT NULL,
  `processFunction` varchar(1024) NOT NULL,
  `userRoleId` bigint(20) NOT NULL,
  `userRoleText` varchar(128) NOT NULL,
  `userIp` varchar(1024) NOT NULL,
  `userAgent` varchar(128) NOT NULL,
  `agentString` varchar(1024) NOT NULL,
  `platform` varchar(128) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_log` (`id`, `userId`, `userName`, `process`, `processFunction`, `userRoleId`, `userRoleText`, `userIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES ('1', '1', 'Süleyman Aydın', 'Log Görüntüleme', 'Admin/logHistory', '1', 'Admin', '::1', 'Chrome 64.0.3282.167', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', 'Windows 10', '2018-02-22 14:12:09');
INSERT INTO `tbl_log` (`id`, `userId`, `userName`, `process`, `processFunction`, `userRoleId`, `userRoleText`, `userIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES ('2', '1', 'Süleyman Aydın', 'Kullanıcı Listeleme', 'Admin/userListing', '1', 'Admin', '::1', 'Chrome 64.0.3282.167', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', 'Windows 10', '2018-02-22 14:12:10');
INSERT INTO `tbl_log` (`id`, `userId`, `userName`, `process`, `processFunction`, `userRoleId`, `userRoleText`, `userIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES ('3', '1', 'Süleyman Aydın', 'Kullanıcı Listeleme', 'Admin/userListing', '1', 'Admin', '::1', 'Chrome 64.0.3282.167', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', 'Windows 10', '2018-02-22 14:12:11');
INSERT INTO `tbl_log` (`id`, `userId`, `userName`, `process`, `processFunction`, `userRoleId`, `userRoleText`, `userIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES ('4', '1', 'Süleyman Aydın', 'Log Görüntüleme', 'Admin/logHistory', '1', 'Admin', '::1', 'Chrome 64.0.3282.167', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', 'Windows 10', '2018-02-22 14:12:12');
INSERT INTO `tbl_log` (`id`, `userId`, `userName`, `process`, `processFunction`, `userRoleId`, `userRoleText`, `userIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES ('5', '1', 'Süleyman Aydın', 'Yedek Log Yükleme', 'Admin/logHistoryUpload', '1', 'Admin', '::1', 'Chrome 64.0.3282.167', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', 'Windows 10', '2018-02-22 14:12:13');
INSERT INTO `tbl_log` (`id`, `userId`, `userName`, `process`, `processFunction`, `userRoleId`, `userRoleText`, `userIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES ('6', '1', 'Süleyman Aydın', 'Yedek Log Görüntüleme', 'Admin/logHistoryBackup', '1', 'Admin', '::1', 'Chrome 64.0.3282.167', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', 'Windows 10', '2018-02-22 14:12:15');
INSERT INTO `tbl_log` (`id`, `userId`, `userName`, `process`, `processFunction`, `userRoleId`, `userRoleText`, `userIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES ('7', '1', 'Süleyman Aydın', 'Tüm görevler', 'Manager/tasks', '1', 'Admin', '::1', 'Chrome 64.0.3282.167', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', 'Windows 10', '2018-02-22 15:08:24');
INSERT INTO `tbl_log` (`id`, `userId`, `userName`, `process`, `processFunction`, `userRoleId`, `userRoleText`, `userIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES ('8', '1', 'Süleyman Aydın', 'Giriş', 'Login/loginMe', '1', 'Admin', '::1', 'Chrome 64.0.3282.167', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', 'Windows 10', '2018-02-26 08:25:40');
INSERT INTO `tbl_log` (`id`, `userId`, `userName`, `process`, `processFunction`, `userRoleId`, `userRoleText`, `userIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES ('9', '1', 'Süleyman Aydın', 'Yedek Log Yükleme', 'Admin/logHistoryUpload', '1', 'Admin', '::1', 'Chrome 64.0.3282.167', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', 'Windows 10', '2018-02-26 08:28:38');
INSERT INTO `tbl_log` (`id`, `userId`, `userName`, `process`, `processFunction`, `userRoleId`, `userRoleText`, `userIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES ('10', '1', 'Süleyman Aydın', 'Yedek Log Görüntüleme', 'Admin/logHistoryBackup', '1', 'Admin', '::1', 'Chrome 64.0.3282.167', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', 'Windows 10', '2018-02-26 08:28:41');
INSERT INTO `tbl_log` (`id`, `userId`, `userName`, `process`, `processFunction`, `userRoleId`, `userRoleText`, `userIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES ('11', '1', 'Süleyman Aydın', 'Log Görüntüleme', 'Admin/logHistory', '1', 'Admin', '::1', 'Chrome 64.0.3282.167', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', 'Windows 10', '2018-02-26 08:28:42');


